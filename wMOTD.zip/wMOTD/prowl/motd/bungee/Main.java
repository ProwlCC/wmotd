package prowl.motd.bungee;

import net.md_5.bungee.api.scheduler.*;
import net.md_5.bungee.api.plugin.*;
import java.nio.file.*;
import java.io.*;
import net.md_5.bungee.config.*;
import net.md_5.bungee.api.event.*;
import net.md_5.bungee.event.*;
import java.text.*;
import java.util.*;
import java.util.concurrent.*;
import net.md_5.bungee.api.*;

public class Main extends Plugin implements Listener
{
    private Configuration config;
    ScheduledTask countdown;
    
    public void onEnable() {
        this.getProxy().getPluginManager().registerListener((Plugin)this, (Listener)this);
        this.getProxy().getPluginManager().registerCommand((Plugin)this, (Command)new PingCommand(this));
        if (!this.getDataFolder().exists()) {
            this.getDataFolder().mkdir();
            final File file = new File(this.getDataFolder(), "config.yml");
            if (!file.exists()) {
                try {
                    Throwable t = null;
                    try {
                        final InputStream in = this.getResourceAsStream("config.yml");
                        try {
                            Files.copy(in, file.toPath(), new CopyOption[0]);
                        }
                        finally {
                            if (in != null) {
                                in.close();
                            }
                        }
                    }
                    finally {
                        if (t == null) {
                            final Throwable t2 = null;
                            t = t2;
                        }
                        else {
                            final Throwable t2 = null;
                            if (t != t2) {
                                t.addSuppressed(t2);
                            }
                        }
                    }
                }
                catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        this.saveDefaultConfig();
        this.reloadConfig();
    }
    
    protected Configuration getConfig() {
        return this.config;
    }
    
    protected void reloadConfig() {
        try {
            this.config = ConfigurationProvider.getProvider((Class)YamlConfiguration.class).load(new File(this.getDataFolder(), "config.yml"));
        }
        catch (IOException e) {
            throw new RuntimeException("Unable to load configuration", e);
        }
    }
    
    protected void saveConfig() {
        try {
            ConfigurationProvider.getProvider((Class)YamlConfiguration.class).save(this.getConfig(), new File(this.getDataFolder(), "config.yml"));
        }
        catch (IOException e) {
            throw new RuntimeException("Unable to save configuration", e);
        }
    }
    
    private void saveDefaultConfig() {
    }
    
    @EventHandler
    public void onPing(final ProxyPingEvent e) {
        final ServerPing sp = e.getResponse();
        final String message = this.getConfig().getString("motd").replaceAll("%time", this.getTime()).replaceAll("%newline", "\n");
        sp.getPlayers().setMax(this.config.getInt("slots"));
        sp.setDescription(t(message));
        e.setResponse(sp);
    }
    
    public String getTime() {
        final Configuration config = this.getConfig();
        final String dateStop = config.getString("date");
        final SimpleDateFormat format = new SimpleDateFormat("MM/dd/yy HH:mm:ss");
        Date date = null;
        try {
            format.setTimeZone(TimeZone.getTimeZone(config.getString("timezone")));
            date = format.parse(dateStop);
        }
        catch (ParseException e) {
            e.printStackTrace();
        }
        final Date current = new Date();
        final long diff = date.getTime() - current.getTime();
        if (diff < 0L) {
            return config.getString(t("time-value-end"));
        }
        if (config.getInt("clock-type") == 1) {
            final long days = TimeUnit.MILLISECONDS.toDays(diff);
            final long hours = TimeUnit.MILLISECONDS.toHours(diff);
            final long minutes = TimeUnit.MILLISECONDS.toMinutes(diff);
            final long seconds = TimeUnit.MILLISECONDS.toSeconds(diff);
            final long rhours = (days == 0L) ? hours : (hours % (days * 24L));
            final long rminutes = (hours == 0L) ? minutes : (minutes % (hours * 60L));
            final long rseconds = (minutes == 0L) ? seconds : (seconds % (minutes * 60L));
            final StringBuilder sb = new StringBuilder();
            if (days > 1L) {
            	 sb.append(String.valueOf(days) + config.getString("time-day"));
            }
            if (days == 1L) {
            	sb.append(String.valueOf(days) + config.getString("time-day"));
            }
            if (rhours > 1L) {
                sb.append(String.valueOf((days > 0L) ? " " : "") + rhours + config.getString("time-hours"));
            }
            if (rhours == 1L) {
                sb.append(String.valueOf((days > 0L) ? " " : "") + rhours + config.getString("time-hours"));
            }
            if (rminutes > 1L) {
                sb.append(String.valueOf(((days > 0L && hours <= 0L) || hours > 0L) ? " " : "") + rminutes + config.getString("time-minutes"));
            }
            if (rminutes == 1L) {
                sb.append(String.valueOf(((days > 0L && hours <= 0L) || hours > 0L) ? " " : "") + rminutes + config.getString("time-minutes"));
            }
            if (rseconds > 1L) {
                sb.append(String.valueOf((((days > 0L || hours > 0L) && minutes <= 0L) || minutes > 0L) ? " " : "") + rseconds + config.getString("time-seconds"));
            }
            if (rseconds == 1L) {
                sb.append(String.valueOf((((days > 0L || hours > 0L) && minutes <= 0L) || minutes > 0L) ? " " : "") + rseconds + config.getString("time-seconds"));
            }
            return sb.toString();
        }
        if (config.getInt("clock-type") == 2) {
            final long seconds2 = TimeUnit.MILLISECONDS.toSeconds(diff);
            final long minutes2 = TimeUnit.MILLISECONDS.toMinutes(diff);
            final long hours2 = TimeUnit.MILLISECONDS.toHours(diff);
            final long days2 = TimeUnit.MILLISECONDS.toDays(diff);
            final long rhours = (days2 == 0L) ? hours2 : (hours2 % (days2 * 24L));
            final long rminutes = (hours2 == 0L) ? minutes2 : (minutes2 % (hours2 * 60L));
            final long rseconds = (minutes2 == 0L) ? seconds2 : (seconds2 % (minutes2 * 60L));
            return String.valueOf(days2) + ":" + rhours + ":" + rminutes + ":" + rseconds;
        }
        return null;
    }
    
    public void startCountdown() {
        this.countdown = this.getProxy().getScheduler().schedule((Plugin)this, (Runnable)new Runnable() {
            @Override
            public void run() {
                if (Main.this.getCountdown() == 0) {
                    Main.this.getProxy().getScheduler().cancel(Main.this.countdown);
                    Main.this.getProxy().getPluginManager().dispatchCommand(Main.this.getProxy().getConsole(), Main.this.getConfig().getString("command-finish"));
                    System.out.println("Command-Finish has been successfully executed!");
                }
            }
        }, 0L, 1L, TimeUnit.SECONDS);
    }
    
    public int getCountdown() {
        this.config = this.getConfig();
        final String dateStop = this.config.getString("date");
        final SimpleDateFormat format = new SimpleDateFormat("MM/dd/yy HH:mm:ss");
        Date date = null;
        try {
            format.setTimeZone(TimeZone.getTimeZone(this.config.getString("timezone")));
            date = format.parse(dateStop);
        }
        catch (ParseException e) {
            e.printStackTrace();
        }
        final Date current = new Date();
        final long diff = date.getTime() - current.getTime();
        if (diff > 0L) {
            final Integer seconds = (int)TimeUnit.MILLISECONDS.toSeconds(diff);
            return seconds;
        }
        return 0;
    }
    
    public static String t(final String i) {
        return ChatColor.translateAlternateColorCodes('&', i);
    }
}
