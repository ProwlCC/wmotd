package prowl.motd.bungee;

import net.md_5.bungee.api.plugin.*;
import net.md_5.bungee.api.*;

public class PingCommand extends Command
{
    private Main plugin;
    
    public PingCommand(final Main plugin) {
        super("motdcountdown");
        this.plugin = plugin;
    }
    
    public void execute(final CommandSender sender, final String[] args) {
        if (args.length == 1) {
            if (args[0].equalsIgnoreCase("reload")) {
                if (sender.hasPermission("motdcountdown.reload")) {
                    this.plugin.reloadConfig();
                    sender.sendMessage(t("&cConfig reloaded"));
                }
                else {
                    sender.sendMessage(t("&cNo permission"));
                }
            }
            else {
                sender.sendMessage("&cError, Invalid usage: /motdcountdown reload");
            }
        }
        else {
            sender.sendMessage("&cToo many arguments.");
        }
    }
    
    public static String t(final String i) {
        return ChatColor.translateAlternateColorCodes('&', i);
    }
}
