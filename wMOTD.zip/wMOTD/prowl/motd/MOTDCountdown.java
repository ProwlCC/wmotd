package prowl.motd;

import org.bukkit.plugin.java.*;
import org.bukkit.*;
import org.bukkit.plugin.*;
import org.bukkit.configuration.file.*;
import org.bukkit.scheduler.*;
import java.text.*;
import java.util.*;
import java.util.concurrent.*;
import org.bukkit.event.server.*;
import org.bukkit.event.*;
import org.bukkit.command.*;
import org.bukkit.command.CommandSender;

import net.md_5.bungee.api.*;
import net.md_5.bungee.api.ChatColor;

public class MOTDCountdown extends JavaPlugin implements Listener
{
    private static MOTDCountdown instance;
    int taskId;
    
    public MOTDCountdown() {
        this.taskId = -1;
        MOTDCountdown.instance = this;
    }
    
    public static MOTDCountdown getInstance() {
        return MOTDCountdown.instance;
    }
    
    public void onEnable() {
        final FileConfiguration config = this.getConfig();
        Bukkit.getServer().getPluginManager().registerEvents((Listener)this, (Plugin)this);
        config.options().copyDefaults(true);
        this.saveDefaultConfig();
        this.startCountdown();
    }
    
    public void startCountdown() {
        final BukkitScheduler scheduler = this.getServer().getScheduler();
        this.taskId = scheduler.scheduleSyncRepeatingTask((Plugin)this, (Runnable)new Runnable() {
            @Override
            public void run() {
                if (MOTDCountdown.this.getCountdown() == 0) {
                    MOTDCountdown.this.cancelTask(MOTDCountdown.this.taskId);
                    MOTDCountdown.this.taskId = -1;
                    Bukkit.getServer().dispatchCommand((CommandSender)MOTDCountdown.this.getServer().getConsoleSender(), MOTDCountdown.this.getConfig().getString("command-finish"));
                    System.out.println("Command-Finish has been successfully executed!");
                }
            }
        }, 0L, 20L);
    }
    
    public void cancelTask(final int id) {
        Bukkit.getServer().getScheduler().cancelTask(id);
    }
    
    public int getCountdown() {
        final FileConfiguration config = this.getConfig();
        final String dateStop = config.getString("date");
        final SimpleDateFormat format = new SimpleDateFormat("MM/dd/yy HH:mm:ss");
        Date date = null;
        try {
            format.setTimeZone(TimeZone.getTimeZone(config.getString("timezone")));
            date = format.parse(dateStop);
        }
        catch (ParseException e) {
            e.printStackTrace();
        }
        final Date current = new Date();
        final long diff = date.getTime() - current.getTime();
        if (diff > 0L) {
            final Integer seconds = (int)TimeUnit.MILLISECONDS.toSeconds(diff);
            return seconds;
        }
        return 0;
    }
    
    @EventHandler
    public void onPing(final ServerListPingEvent e) {
        final FileConfiguration config = this.getConfig();
        final String message = config.getString("motd").replaceAll("%time", this.getTime()).replaceAll("%newline", "\n");
        e.setMotd(t(message));
        e.setMaxPlayers(config.getInt("slots"));
    }
    
    public boolean onCommand(final CommandSender sender, final Command cmd, final String commandLabel, final String[] args) {
        if (cmd.getName().equalsIgnoreCase("motdcountdown")) {
            if (args.length == 1) {
                if (args[0].equalsIgnoreCase("reload")) {
                    if (sender.hasPermission("motdcountdown.reload")) {
                        this.reloadConfig();
                        sender.sendMessage(t("&cMOTDCountdown reloaded successfully!"));
                        return true;
                    }
                }
                else {
                    sender.sendMessage(t("&cError, Invalid Usage, use: /motdcountdown reload"));
                }
            }
            else {
                sender.sendMessage(t("&cError, Invalid Usage, use: /motdcountdown reload"));
            }
        }
        return true;
    }
    
    public String getTime() {
        final FileConfiguration config = this.getConfig();
        final String dateStop = config.getString("date");
        final SimpleDateFormat format = new SimpleDateFormat("MM/dd/yy HH:mm:ss");
        Date date = null;
        try {
            format.setTimeZone(TimeZone.getTimeZone(config.getString("timezone")));
            date = format.parse(dateStop);
        }
        catch (ParseException e) {
            e.printStackTrace();
        }
        final Date current = new Date();
        final long diff = date.getTime() - current.getTime();
        if (diff < 0L) {
            return config.getString(t("time-value-end"));
        }
        if (config.getInt("clock-type") == 1) {
            final long days = TimeUnit.MILLISECONDS.toDays(diff);
            final long hours = TimeUnit.MILLISECONDS.toHours(diff);
            final long minutes = TimeUnit.MILLISECONDS.toMinutes(diff);
            final long seconds = TimeUnit.MILLISECONDS.toSeconds(diff);
            final long rhours = (days == 0L) ? hours : (hours % (days * 24L));
            final long rminutes = (hours == 0L) ? minutes : (minutes % (hours * 60L));
            final long rseconds = (minutes == 0L) ? seconds : (seconds % (minutes * 60L));
            final StringBuilder sb = new StringBuilder();
            if (days > 1L) {
           	 sb.append(String.valueOf(days) + config.getString("time-day"));
           }
           if (days == 1L) {
           	sb.append(String.valueOf(days) + config.getString("time-day"));
           }
           if (rhours > 1L) {
               sb.append(String.valueOf((days > 0L) ? " " : "") + rhours + config.getString("time-hours"));
           }
           if (rhours == 1L) {
               sb.append(String.valueOf((days > 0L) ? " " : "") + rhours + config.getString("time-hours"));
           }
           if (rminutes > 1L) {
               sb.append(String.valueOf(((days > 0L && hours <= 0L) || hours > 0L) ? " " : "") + rminutes + config.getString("time-minutes"));
           }
           if (rminutes == 1L) {
               sb.append(String.valueOf(((days > 0L && hours <= 0L) || hours > 0L) ? " " : "") + rminutes + config.getString("time-minutes"));
           }
           if (rseconds > 1L) {
               sb.append(String.valueOf((((days > 0L || hours > 0L) && minutes <= 0L) || minutes > 0L) ? " " : "") + rseconds + config.getString("time-seconds"));
           }
           if (rseconds == 1L) {
               sb.append(String.valueOf((((days > 0L || hours > 0L) && minutes <= 0L) || minutes > 0L) ? " " : "") + rseconds + config.getString("time-seconds"));
           }
            return sb.toString();
        }
        if (config.getInt("clock-type") == 2) {
            final long seconds2 = TimeUnit.MILLISECONDS.toSeconds(diff);
            final long minutes2 = TimeUnit.MILLISECONDS.toMinutes(diff);
            final long hours2 = TimeUnit.MILLISECONDS.toHours(diff);
            final long days2 = TimeUnit.MILLISECONDS.toDays(diff);
            final long rhours = (days2 == 0L) ? hours2 : (hours2 % (days2 * 24L));
            final long rminutes = (hours2 == 0L) ? minutes2 : (minutes2 % (hours2 * 60L));
            final long rseconds = (minutes2 == 0L) ? seconds2 : (seconds2 % (minutes2 * 60L));
            return String.valueOf(days2) + ":" + rhours + ":" + rminutes + ":" + rseconds;
        }
        return null;
    }
    
    public static String t(final String i) {
        return ChatColor.translateAlternateColorCodes('&', i);
    }
}
